slave_array=(10.224.13.132 10.224.13.180 10.224.13.190 10.224.13.235 10.224.14.1 10.224.14.123 10.224.14.143 10.224.14.18 10.224.14.56 10.224.14.78); index=10 && while [ ${index} -gt 0 ]; do for slave in ${slave_array[@]}; do if echo 'test open port' 2>/dev/null > /dev/tcp/${slave}/1099; then echo ${slave}' ready' && slave_array=(${slave_array[@]/${slave}/}); index=$((index-1)); else echo ${slave}' not ready'; fi; done; echo 'Waiting for slave readiness'; sleep 2; done
echo "Installing needed plugins for master"
cd /opt/jmeter/apache-jmeter/bin
sh PluginsManagerCMD.sh install-for-jmx KyleTP028.jmx
echo "Done installing plugins, launching test"
jmeter -Ghost= -Gport= -Gprotocol= -Gthreads= -Gduration= -Grampup= --reportatendofloadtests --reportoutputfolder /report/report-KyleTP028.jmx-2024-06-04_173658 --logfile /opt/jmeter/report/KyleTP028.jmx_2024-06-04_173658.jtl --nongui --testfile KyleTP028.jmx -Dserver.rmi.ssl.disable=true --remotestart 10.224.13.132,10.224.13.180,10.224.13.190,10.224.13.235,10.224.14.1,10.224.14.123,10.224.14.143,10.224.14.18,10.224.14.56,10.224.14.78 >> jmeter-master.out 2>> jmeter-master.err &
java -jar /opt/jmeter/apache-jmeter/lib/jolokia-java-agent.jar start JMeter >> jmeter-master.out 2>> jmeter-master.err
echo "Starting load test at : Tue Jun  4 17:36:58 SAST 2024" && sleep 9999999999d && wait
